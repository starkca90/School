/** Automatically generated file. DO NOT MODIFY */
package com.starkca.todolistintent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}